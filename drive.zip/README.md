# Drivexceed
Google Drive video player dengan JW Player 8.3.3

## Pemasangan
- Unduh repositori ini dalam bentuk arsip `.zip`
- Unggah ke penyedia hosting, kemudian ekstrak file `.zip`
- Akses `http://domain.kamu/drivexceed.php?id=ID`, contoh: `http://drivexceed.rf.gd/?id=18zzCGg-NcJBqFE5LFhOw5CIF1MSULFmo`

## Tutorial <iframe>
```html
<iframe src="http://drivexceed.rf.gd/?id=18zzCGg-NcJBqFE5LFhOw5CIF1MSULFmo" frameborder="0" width="100%" height="400" allowfullscreen="allowfullscreen"></iframe>
```
